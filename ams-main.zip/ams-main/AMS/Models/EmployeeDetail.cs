﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace AMS.Models
{
    public class EmployeeDetail
    {
        public string name { get; set; }
        public string supervisorId { get; set; }
    }
}